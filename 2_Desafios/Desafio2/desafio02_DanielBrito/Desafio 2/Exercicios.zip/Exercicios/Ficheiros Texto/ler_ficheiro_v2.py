with open("meu_ficheiro.txt","r",encoding='utf-8') as ficheiro:
    texto = ficheiro.read()

print(texto)
