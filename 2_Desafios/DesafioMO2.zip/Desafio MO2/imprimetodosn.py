for i in range(1,100):
    if i % 3 != 0:
        print(i)
        