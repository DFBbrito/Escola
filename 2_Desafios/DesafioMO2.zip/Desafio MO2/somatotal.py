"""
Daniel Brito
"""

soma_total = 0

while soma_total <= 100:
    numero = int(input("Digite um número inteiro: "))
    soma_total += numero

print("A soma total é", soma_total)
