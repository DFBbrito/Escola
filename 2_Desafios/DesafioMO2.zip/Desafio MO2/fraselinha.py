"""
Daniel Brito
"""
frase = str(input("Escreve uma frase: "))


for letra in frase:
    print(letra)