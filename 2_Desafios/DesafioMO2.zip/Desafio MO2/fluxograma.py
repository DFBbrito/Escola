"""
Daniel Brito
"""    
contar= 0 #int(input("Insira 5 numeros superiores a 10 e inferiores a 100: "))


while contar < 5:
    n = int(input("Numero:"))
    if n > 10 and n<100:
        contar= contar + 1
    print(contar)






